const User = require('../models/user');


exports.addPost = async (req, res) => {
    try{
        const { desc, imageLink } = req.body;
        let userId = req.user._id;

        const addPost = new PostModel({ user: userId, desc, imageLink })

        if(!addPost){
            return res.status(400).json({ error: "Something Went Wrong" });
        }
        await addPost.save();
        return res.status(400).json({ 
            message:"Post successfully",
            post: addPost
        })

    }catch(error){
        console.error(error);
        res.status(500).json({ error: "Internal Server Error", message:error.message });
    }
}

exports.likeDislikePost = async (req, res) => {
    try{
        let selfId = req.user._id;
        let{ postId } = req.body;
        let post = await PostModel.findById(postId);
        if(!post){
            return res.status(400).json({ error: "No Such Post Exist" });
        }
        const index = post.likes.findIndex(id=> id.equals(selfId));

        if(index !== -1){
            //User alerady liked the post, remove like
            post.likes.splice(index, 1);
        }else{
            //user has not likesd the post, add like
            post.likes.push(selfId);
        }
        
    }catch(err){
        console.error(err);
        res.status(500).json({ error: 'Server Error', message: err.message });
    }
}